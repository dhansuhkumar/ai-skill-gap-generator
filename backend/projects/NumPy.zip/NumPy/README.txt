Starter project for skill: NumPy
Instructions: Try to implement a small project using this skill.
