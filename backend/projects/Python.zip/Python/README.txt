Starter project for skill: Python
Instructions: Try to implement a small project using this skill.
