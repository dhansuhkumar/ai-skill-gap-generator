Starter project for skill: Pandas
Instructions: Try to implement a small project using this skill.
