Starter project for skill: Node.js
Instructions: Try to implement a small project using this skill.
