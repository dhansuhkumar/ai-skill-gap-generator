C programming details to do so
