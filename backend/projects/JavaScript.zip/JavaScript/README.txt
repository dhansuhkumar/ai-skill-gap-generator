Starter project for skill: JavaScript
Instructions: Try to implement a small project using this skill.
