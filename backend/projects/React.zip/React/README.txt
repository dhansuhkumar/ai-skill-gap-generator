Starter project for skill: React
Instructions: Try to implement a small project using this skill.
